package at.fhtw.bif3.swe1.simpledatastore.repository;

import at.fhtw.bif3.swe1.simpledatastore.model.PlaygroundPointRecord;

import java.sql.SQLException;
import java.util.List;

public interface PlaygroundRepository {

    List<PlaygroundPointRecord> findByBezirk(int bezirk) throws SQLException;
    List<PlaygroundPointRecord> findByBezirkAndType(int bezirk, String type) throws SQLException;

}
