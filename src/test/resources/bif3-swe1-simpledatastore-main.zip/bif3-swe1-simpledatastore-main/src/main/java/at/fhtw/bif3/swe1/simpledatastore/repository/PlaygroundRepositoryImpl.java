package at.fhtw.bif3.swe1.simpledatastore.repository;

import at.fhtw.bif3.swe1.simpledatastore.model.PlaygroundPointRecord;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PlaygroundRepositoryImpl implements PlaygroundRepository {

    private final Connection connection;

    public PlaygroundRepositoryImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public List<PlaygroundPointRecord> findByBezirk(int bezirk) throws SQLException {
        String sqlStmt = """
    select fid,
           objectid,
           shape,
           anlname,
           bezirk,
           spielplatzdetail,
           typdetail,
           seannocaddata
    from playgroundpoints
    where (bezirk = -1 or bezirk = ?)
    """;
        PreparedStatement stmt = connection.prepareStatement(sqlStmt);
        stmt.setInt(1, bezirk);

        return execute(stmt);
    }

    @Override
    public List<PlaygroundPointRecord> findByBezirkAndType(int bezirk, String type) throws SQLException {
        String sqlStmt = """
    select fid,
           objectid,
           shape,
           anlname,
           bezirk,
           spielplatzdetail,
           typdetail,
           seannocaddata
    from playgroundpoints
    where (bezirk = -1 or bezirk = ?) and (typdetail = ?)
    """;
        PreparedStatement stmt = connection.prepareStatement(sqlStmt);
        stmt.setInt(1, bezirk);
        stmt.setString(2, type);

        return execute(stmt);
    }

    private List<PlaygroundPointRecord> execute(PreparedStatement stmt) throws SQLException {
        ResultSet resultSet = stmt.executeQuery();
        List<PlaygroundPointRecord> list = new ArrayList<>();
        while(resultSet.next()){
            var data = new PlaygroundPointRecord(
                    resultSet.getString(1),
                    resultSet.getInt(2),
                    resultSet.getString(3),
                    resultSet.getString(4),
                    resultSet.getInt(5),
                    resultSet.getString(6),
                    resultSet.getString(7),
                    resultSet.getString(8));
            list.add(data);
        }

        return list;
    }
}
