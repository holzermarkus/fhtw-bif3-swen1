package at.fhtw.bif3.swe1.simpledatastore.model;

import java.io.Serializable;


public record PlaygroundPointRecord(
        String fId,
        Integer objectId,
        String shape,
        String anlName,
        Integer bezirk,
        String spielplatzDetail,
        String typDetail,
        String seAnnoCadData) implements Serializable /* necessary for Object-Streams */
{
}
