# bif3-swe1-simpledatastore
Domenstrates reading a simple datastore with streams
